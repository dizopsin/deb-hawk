require 'test_helper'

class ConstraintsHelperTest < ActionView::TestCase
end
