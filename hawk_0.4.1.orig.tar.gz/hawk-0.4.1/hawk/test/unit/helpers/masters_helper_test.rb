require 'test_helper'

class MastersHelperTest < ActionView::TestCase
end
