# Global options for HA Web Konsole
#
# Note that you must restart the web server after changing
# settings here.
#
# Nothing here ATM, sorry...
#
