require 'test_helper'

class ClonesHelperTest < ActionView::TestCase
end
