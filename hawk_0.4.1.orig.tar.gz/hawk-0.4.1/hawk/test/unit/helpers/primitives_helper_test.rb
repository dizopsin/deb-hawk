require 'test_helper'

class PrimitivesHelperTest < ActionView::TestCase
end
