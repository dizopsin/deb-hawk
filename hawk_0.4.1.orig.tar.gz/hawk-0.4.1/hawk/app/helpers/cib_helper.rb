module CibHelper
end
