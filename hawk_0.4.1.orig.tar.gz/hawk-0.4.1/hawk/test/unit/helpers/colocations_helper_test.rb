require 'test_helper'

class ColocationsHelperTest < ActionView::TestCase
end
