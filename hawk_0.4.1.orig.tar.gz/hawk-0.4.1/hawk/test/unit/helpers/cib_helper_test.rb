require 'test_helper'

class CibHelperTest < ActionView::TestCase
end
