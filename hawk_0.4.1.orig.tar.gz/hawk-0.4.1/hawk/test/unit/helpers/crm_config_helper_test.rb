require 'test_helper'

class CrmConfigHelperTest < ActionView::TestCase
end
